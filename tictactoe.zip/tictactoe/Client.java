package java_network.tictactoe;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client implements Runnable {
    String host;
    int port;
    Scanner rspScanner = new Scanner(System.in);
    static boolean win=false;
    static boolean lose=false;
    static boolean draw=false;
    

    static String[] board = {" "," "," "," "," "," "," "," "," "};
    static boolean[] mycheack = new boolean[9];
    static boolean[] emcheack = new boolean[9];
    static boolean[] totalcheack = new boolean[9];

    public Client(String host, int port) {
        this.host = host;
        this.port = port;
        
    }

    public static void viewboard() {
        for(int i =0;i<3;i++)
                System.out.println("["+board[i*3]+"]"+" ["+board[i*3+1]+"]"+" ["+board[i*3+2]+"]");
            
    }

    public static void iswin(){
        for(int i =0;i<3;i++)
            if(mycheack[i*3]&&mycheack[i*3+1]&&mycheack[i*3+2]){win=true;}
        for(int i =0;i<3;i++)
            if(mycheack[i]&&mycheack[i+3]&&mycheack[i+6]){win=true;}
        if(mycheack[0]&&mycheack[4]&&mycheack[8]){win=true;}
        if(mycheack[2]&&mycheack[4]&&mycheack[6]){win=true;}
        if(win){
            System.out.println("your win");
            System.exit(0);
        }
    }

    public static void islose(){
        for(int i =0;i<3;i++)
            if(emcheack[i*3]&&emcheack[i*3+1]&&emcheack[i*3+2]){lose=true;}
        for(int i =0;i<3;i++)
            if(emcheack[i]&&emcheack[i+3]&&emcheack[i+6]){lose=true;}
        if(emcheack[0]&&emcheack[4]&&emcheack[8]){lose=true;}
        if(emcheack[2]&&emcheack[4]&&emcheack[6]){lose=true;}
        if(lose){
            System.out.println("your lose");
            System.exit(0);
        }
    }
     public static void isdraw(){
        if(totalcheack[0]&&totalcheack[1]&&totalcheack[2]&&totalcheack[3]&&totalcheack[4]&&
        totalcheack[5]&&totalcheack[6]&&totalcheack[7]&&totalcheack[8]){draw=true;}
         if(draw){System.out.println("Draw!");System.exit(0);}
    }

    public static void setboardO(int num){
        board[num-1]="O";
    }

    public static void setboardX(int num){
        board[num-1]="X";
    }

    public static void setmycheack(int num){
        mycheack[num-1]=true;
    }

    public static void setemcheack(int num){
        emcheack[num-1]=true;
    }

     public static void settotalcheack(int num){
        totalcheack[num-1]=true;
    }


    @Override
    public void run() {
        try (Socket socket = new Socket(host, port);
                BufferedReader terminalInput = new BufferedReader(new InputStreamReader(System.in));
                PrintWriter terminalOutput = new PrintWriter(System.out);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter output = new PrintWriter(socket.getOutputStream())) {

                
                String message;
                
                System.out.print("순서를 정하기 위해 가위, 바위, 보 중 하나를 입력해 주세요. >>");
                

              

            Thread receiverThread = new Thread(()->{
            while (!socket.isClosed()) {
                try{
                String receivedMessage = input.readLine(); // 받은 메세지
                int num = receivedMessage.charAt(0)-48; // 체크할자리
            
                if(receivedMessage.substring(1).equals(socket.getLocalPort()+"")){
                    Client.setboardO(num);
                    Client.setmycheack(num);
                    Client.settotalcheack(num);
                    Client.viewboard();
                    Client.iswin();
                    Client.isdraw();
                } else{
                    Client.setboardX(num);
                    Client.setemcheack(num);
                    Client.settotalcheack(num);
                    System.out.println();
                    Client.viewboard();
                    Client.islose();
                    Client.isdraw();
                }


                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }});

            receiverThread.start();
            while (((message = terminalInput.readLine()) != null)&&!socket.isClosed()) {
                output.println(message+socket.getLocalPort());
                output.flush();
            }

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(new Client("localhost", 12345));
        Client.viewboard();
        thread.start();
        thread.join();

        
    }
}
