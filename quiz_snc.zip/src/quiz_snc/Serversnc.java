package quiz_snc;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Serversnc {
    public static void main(String[] args) throws InterruptedException{
        int portnum = 1234;        

        try(ServerSocket serverSocket = new ServerSocket(portnum)){
            System.out.println("server Clear ");   //성공
            
            while (!serverSocket.isClosed()) {                
                System.out.println("Waiting for Client...");    //client 대기
                Socket socket = serverSocket.accept();     
                System.out.println("Client Connect Clear "+ socket.getInetAddress());   //성공
                
                SNCsnc snc = new SNCsnc(socket.getInputStream(), socket.getOutputStream(), socket.getInetAddress());
            
                snc.start();
                snc.stop2();
                //snc 기다리지 않고 다시 시작
            }
                        
            
        }catch(IOException e){
            System.err.println(e.getMessage());
        }



    }

}
