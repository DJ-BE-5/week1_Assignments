package quiz_snc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

public class Clientsnc {
    public static void main (String[] args) throws InterruptedException {
        boolean running = true;
        
        Scanner scanner = new Scanner(System.in);
        String helpList = "Usage: snc [option] [hostname] [port] \n" + //
                        "Options: \n" + 
                        "-l  <port>  server로 동작시 입력받은 port로 listen";
        System.out.println(helpList + "\n");   //사용법 출력
        String command = scanner.nextLine();    //Scanner 클래스로 커맨드 입력
        String port = command.substring(3);
        int portnum = Integer.parseInt(port);
        System.out.println(portnum);
        try (Socket socket = new Socket("localhost",portnum)){
            BufferedInputStream input = new BufferedInputStream(socket.getInputStream());
            BufferedOutputStream output = new BufferedOutputStream(socket.getOutputStream()); 

            while (socket.isConnected()) {  //디버그시 연결
                
                output.write(command.getBytes());       
                output.flush();                         //커맨드 server로 전송
                           
                byte[] buffer = new byte[256];
                int length = input.read(buffer,0,buffer.length);
                
                if(length > 0 && running == true){
                    String echomessage = new String(Arrays.copyOf(buffer, length));
                    System.out.println(echomessage);

                    Thread.sleep(100);
                }
            }  
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        scanner.close();

    }

}
