package quiz_snc;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;

public class SNCsnc extends Thread {
    InputStream input;
    OutputStream output;
    boolean running = false;
    byte[] buffer = new byte[256];
    BufferedReader bufferedInput;
    BufferedOutputStream bufferedOutput;
    InetAddress inetadd;

    public SNCsnc (InputStream input, OutputStream output, InetAddress inetadd){
        bufferedInput = new BufferedReader(new InputStreamReader(input));
        bufferedOutput = new BufferedOutputStream(output);
        this.inetadd = inetadd;
        this.output = output;
    }
    public void stop2(){
        running = false;
    }
    
    public void write(String message){
        try {
            bufferedOutput.write(message.getBytes());
            bufferedOutput.flush();            
        } catch (IOException e) {
            stop2();
        }
    }
    
    @Override
    public void run() {        
        running = true;
        while (running) {
            try{
                String message = " ~$ snc " + bufferedInput.readLine();
                System.out.println("Receive: " + message);
                
                String returnmessage = "GET /  HTTP/1.1" + 
                                        "Host: " + inetadd;
                output.write(returnmessage.getBytes());
                
                    stop2();       
            } catch (IOException e){
                System.err.println(e.getMessage());
                stop2();
            }
        }
    }
    
    
}

